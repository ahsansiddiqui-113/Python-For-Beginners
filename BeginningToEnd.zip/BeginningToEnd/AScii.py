c = 'p'
print("The ASCII value of '" + c + "' is", ord(c))