a = int(input("enter a number"))
b = int(input("enter the second number"))
c = int(input("enter the third number"))

s = (a + b + c) / 2

area = (s*(s-a)*(s-b)*(s-c)) ** 0.5

print('The area of the triangle is' ,area)