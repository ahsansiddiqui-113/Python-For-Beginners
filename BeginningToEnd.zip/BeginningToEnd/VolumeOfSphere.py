radius=6
volume=4/3*(3.14)*radius*radius
print(volume)