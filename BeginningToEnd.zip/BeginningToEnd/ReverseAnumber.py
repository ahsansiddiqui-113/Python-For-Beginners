number=int(input("enter a number"))
reverse=0
while number>0:
    reverse=(reverse*10)+(number%10)
    number//=10
print("reverse number is  " , reverse)