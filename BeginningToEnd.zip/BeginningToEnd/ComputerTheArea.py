radius=5
area=(3.14)*radius*radius
print(area)