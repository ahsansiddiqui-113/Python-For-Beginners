def sum(x, y, z):
    sum = x + y + z

    if x == y == z:
        sum = sum * 3
    return sum

print(sum(4,5 ,6 ))
print(sum(6, 6, 6))