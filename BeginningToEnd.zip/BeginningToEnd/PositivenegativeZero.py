num=int(input("enter a number "))
if num>0:
    print("positive")
elif num==0:
    print("zero")
elif num<0:
    print("negative")
else:
    print("error")