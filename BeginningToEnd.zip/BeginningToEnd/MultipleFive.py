num=int(input("enter the number"))
if(num %5==0):
    print("the number is divisible by 5")
else:
    print("number not divisible by 5 ")