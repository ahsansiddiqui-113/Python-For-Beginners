x=int(input("enter number"))
y=int(input("enter 2nd number"))
res=(x+y)*(x+y)
print(res)