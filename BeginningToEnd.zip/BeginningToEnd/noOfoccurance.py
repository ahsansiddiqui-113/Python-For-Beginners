count=0
str="hello world"
char='e'
for i in str:
    if i==char:
        count+=1
print("the occurance of" ,char,"is",count)