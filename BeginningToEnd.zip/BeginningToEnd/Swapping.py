num1=4
num2=5
print("after swapping")
temp=num1
num1=num2
num2=temp
print(num1)
print(num2)
