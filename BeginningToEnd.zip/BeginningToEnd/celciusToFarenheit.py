celsius = float(input("Enter temperature "))
fahrenheit = (celsius * 1.8) + 32
print(str(celsius) + " degree Celsius is equal to " + str(fahrenheit) + " degree Fahrenheit.")