str1 = input("Enter a String : ")
str2 = str1[:]
print("The Copied String is : ", str2)