def isPalindrome(s):
    return s == s[::-1]

s="aha"
ans=isPalindrome(s)

if ans:
    print("its a palindrome")
else:
    print("not a palindrome")