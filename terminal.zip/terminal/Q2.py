#q3
def printSeriesSum(N):
    sum = 0

    for i in range(1, N + 1):

        if (i & 1):
            sum += i / (i + 1)

        else:
            sum -= i / (i + 1)

    print(sum)

if __name__ == "__main__":
    N = int(input("enter "))
    printSeriesSum(N)