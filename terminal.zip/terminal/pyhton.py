#Q1 part 1
string = "python"
result = string * 5
print(result)

#part 2
string1 = "Maryam"
string2 = "Umar"
result = string1 + " " + string2
print(result)

#part3
string1 = "Hello"
string2 = "World"
result = string1 + string2
print(result)

#part 4
string = "Hello World"
if 'oo' not in string:
  print("'oo' is not present in the string.")
else:
  print("'oo' is present in the string.")

# part 5
s = "Hello World"
s = "kk" + s[2:]
print(s)

#Q2 Factorial
#for_loop
for i in ["1/2!","1/4!","1/6!","1/8!","1/10!","1/12!+ "]:
      print(i, end=" ")
# while loop
numbers = ["1/2!","1/4!","1/6!","1/8!","1/10!","1/12!"]
i = 0
while i < len(numbers):
       i += 1
       print(numbers[i], end=" ")



