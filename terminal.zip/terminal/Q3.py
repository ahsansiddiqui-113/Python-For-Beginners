
#first vrsion
for i in range(10):
    print("*",end="")
print("*"*1)

#second version
def display(n):
    for i in range(0,n):
        print("*",end="")
display(6)

#third version

def disp(n,):
string="Maryam"
min_value=min(string)
print(min_value)


s="Hello world"
s="kk"+s[2:]
print(s)
