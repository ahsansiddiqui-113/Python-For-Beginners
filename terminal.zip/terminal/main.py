
#Q3 Car vehicle
def calculate_charges(vehicle_type, num_days):

  if vehicle_type == "M":
    charges = 10 * num_days
  elif vehicle_type == "C":
    charges = 20 * num_days
  elif vehicle_type == "B":
    charges = 30 * num_days
  else:
    # Handle invalid vehicle type
    charges = 0
  return charges

vehicle_type = input("Enter the kinda vehicle: ")
num_days = int(input("Enter the number of days to park the vehicle: "))

total_charges = calculate_charges(vehicle_type, num_days)

print("total charges: Rs ", total_charges)


def calculate_charges(days_parked, hourly_rate, max_charge):
  total_charge = 0

  if days_parked > 0:
    total_charge = hourly_rate * min(24 * days_parked, max_charge)

  print("Total charges are:", total_charge)
  return total_charges



